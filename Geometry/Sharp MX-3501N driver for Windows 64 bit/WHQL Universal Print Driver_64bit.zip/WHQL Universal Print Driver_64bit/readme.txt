==================================================================

                  SHARP PRINTER DRIVER README FILE

==================================================================

Thank you for purchasing our product.
This document gives you the details of important matters which
have to be checked before you install the printer driver.
Be sure to read this document thoroughly before continuing with
the installation.

Some of contents described in this file may be unique,
corresponding to specific kinds of models or drivers.

-----------------------------------------------------------------

 Tips

-----------------------------------------------------------------

- If you upgrade the printer driver, be sure to install the new
  version of the printer driver after deleting the older version.
  Otherwise, the new version of driver may prevent the older
  version of printer driver from working.

- If it is possible, try to use the latest versions of
  software applications, which are compatible with the operating
  system.
  A document created on an old version of a software application
  may not print correctly if printed from a newer version of the
  software. In this case, try saving the document using the
  new version, and then print it.

- Brightly colored characters , lines , fill effects or patterns
  (yellow, light blue, etc.) may not appear when printed.
  In this event, try the following:

 (A) Text consisting only of characters/lines/fill effects/patterns
     created with CAD software:
     Try selecting the "Text To Black" checkbox or
     "Vector To Black" checkbox before printing.
     (In this case, sections where photographs, colored
     characters and lines overlap will all be printed in black.)

 (B) Text that includes photographs, colored characters and
     lines:

     Try decreasing the "Brightness" setting in the "Image
     adjustment" dialog box that appears when you select the
     "Image adjustment" button.
     (This will change the brightness of the overall printed
     image.)

 (C) Other cases
     If you tried the above and still did not obtain the desired
     printing result, change the color of the character or line,
     or make it thicker using the application's control for font
     or line.

- When using a Novell network, if a blank Page prints after the
  Job is completed, turn off the [Form Feed After Job] found in
  the network setting in the PC client software.

- When you print the document created by different computers,
  the computer that you use may not register the fonts that use
  in the document.
  If you print the document in this case, some printed documents
  slightly show the difference against the original document
  (when you print it by the original computer).
  In this case, you are required to register the fonts that use
  in the document into your using computer.

- The position, size, and color of a watermark shown in the
  watermark preview (on the left side of the "Watermark" tab) in
  the driver properties may differ from the actual printed result.
  Use the preview only as a general guideline.

- The displayed "number of pages" in the print queue may not
  be automatically updated. You can press the F5 key to
  update the displayed number.

- If N-Up printing is selected in the "Main" tab when a watermark
  has been selected, an image will appear (the paper image in the
  upper left-hand corner of the tabs) indicating that one watermark
  will be printed on the paper. The image simply indicates that a
  watermark has been selected; it does not indicate the printing
  result. A watermark will actually be printed on each page of the
  document. For example, when a multi-page document is printed using
  2-Up printing, two watermarks will be printed on each sheet of paper.

- Even if the color text with big font size is printed with
  "Text to Black", it may not be printed with black. In that case,
  you may solve this problem by checking "Vector to Black".

- If the printer driver language in use is different from the OS
  language, "Watermark" is not sometimes printed correctly.

-----------------------------------------------------------------

                      About PCL6 Driver

-----------------------------------------------------------------

- When you are using Windows PCL printer driver with some
  applications such as Adobe FreeHand, a watermark might not be
  printed even if you have set to print watermark in the printer
  driver.

- When you use the Lotus123 and the map is not printed, this
  problem may be solved by taking the following measures
  introduced in the Lotus's Web page.

     -Select the 300dpi in the "Input Resolution:".

- When overlapping the characters or being printing as the dotted
  lines change into the full lines, this problem may be solved by
  taking the following measures.

     -Select the 300dpi in the "Input Resolution:".

- If the ruled lines for the graph area is not printed, select
  "Fit To Paper Size" setting in the "Zoom Settings".

- If the watermark of which size is larger than the printing area
  is set, the watermark is not correctly printed. Please adjust
  the watermark size within the printing area.

-----------------------------------------------------------------

                     About Overlay Function

-----------------------------------------------------------------

- When you register the overlay form data, please print only one
  page.

- When you execute the overlay print, please print the document in
  the same printer setting as created the overlay form data.

-----------------------------------------------------------------

          About Limitations for each Application Software

-----------------------------------------------------------------

- Some image printing problems such as PhotoShop printing of an
  oversize image( bigger then the printer margins ) which results
  in extra printed matter or a blue screen. Reducing the image
  size to fit the paper size may solve this problem.

- If Microsoft Publisher is installed, sometimes the Configuration
  settings of the printer will return to the default values.

- When the print error occurs on the Microsoft binder, this
  problem  may be solved by taking the following measures.
  - Turn off the [Print binder as a single job] of the [Binder
    Options].
  - Set all setting items of the printer driver into the default.

- If you stop printing at the alert dialog at the time of print
  in some application software such as Microsoft Word 2000,
  the print may not stop properly.

- If the print setting is changed for Wordpad, please go to the
  Properties page which appears after clicking the [Properties]
  on [Printer...] from [Page Setup] dialog. The print setting from
  [Properties] on [Print] dialog is sometimes not applicable.

- When editing multiple documents in Microsoft Word 2000 or later,
  opening the driver properties and changing the print settings
  for one document may result in changes in the print settings
  for the other documents. In this case, reset the print
  settings before printing each document.

- If a document is printed using a large font in Microsoft Word and
  other applications, the application may be shut down by Windows.
  Fonts larger than 300 points can be set in Microsoft Word; however,
  do not use a font larger than approximately 300 points for
  printing.
  When using a large font in a document, we recommend that you
  frequently save the document so edits are not lost.

- Some English fonts may not print correctly from WordPad. In
  this case, use a different word processor application
  (Microsoft Word, etc.)

- In WordPad, printing may not take place correctly if you
  specify a page range starting from the second page. In this
  event, select "All" for the pages to be printed.

- When "Color Mode" is set to [Automatic] on the [Color] tab of
  the printer driver even if the print result is black and white,
  the following types of print jobs will be counted as 4-color
  (Y (Yellow), M (Magenta),C (Cyan), and Bk (Black)) print jobs.
  To be always counted as a black and white job, select
  [Black and White].
  - When the data is created as color data.
  - When the application treats the data as color data even though
    the data is black and white.
  - When an image is hidden under a black and white image.

- Graphics in a Power Point document may print in black, try the following:
    (1) Select "Print" from the "File" menu in Power Point.
    (2) Set off in the Grayscale function in the Print dialog box.
    (3) Click the "OK" button.
        ===> Printing begins.

- When you use the Internet Explorer with "Protected Mode",
  some functions  may not be used correctly. This probrem may be
  solved by modifying the  "Enable Protected Mode" of the "Security"
  tab to be "OFF" after selecting  the "Tool"-"Internet Options"
  menu in Internet Explorer.

- When you print data by using "2-sided print" or "N-up print"
  prepared by application such as Microsoft Word, you might not
  receive the desired print result.
  We recommend you use the printer driver feature.

-----------------------------------------------------------------

This software is based in part on the work of the Independent
JPEG Group.

This product includes software developed by the OpenSSL Project
for use in the OpenSSL Toolkit. (http://www.openssl.org/)
This product includes cryptographic software written by Eric Young
(eay@cryptsoft.com)

-----------------------------------------------------------------

SHARP Corporation does not guarantee the accuracy of the
information contained in this document and the software (SHARP
printer driver) which accompanies this document for any purpose
other than what they are intended for.

-----------------------------------------------------------------

Microsoft, Windows, Windows Server, Windows Vista, Windows 7 are
registered trademarks of Microsoft Corporation in the United States
and worldwide.
Windows is an abbreviation for the Microsoft Windows operating system.

All other company names and product names are trademarks or
registered trademarks of the respective companies.

-----------------------------------------------------------------

